export default function WatchLater() {
  return <h1>Watch Later</h1>;
}
