export default function Favorites() {
  return <h1>Favorites</h1>;
}
