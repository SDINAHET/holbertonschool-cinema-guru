// src/components/navigation/Header.jsx
import './navigation.css';

function Header({ userUsername, setIsLoggedIn }) {
  const logout = () => {
    // Remove token from localStorage
    localStorage.removeItem('accessToken');
    // Set isLoggedIn to false
    setIsLoggedIn(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <img
          src="https://picsum.photos/100/100"
          alt="User avatar"
        />
        <p className="navbar-welcome">
          Welcome, {userUsername || 'User'} !
        </p>
      </div>

      <div className="navbar-right">
        <span className="navbar-logout" onClick={logout}>
          <span role="img" aria-label="logout">
            🚪
          </span>
          <span>Logout</span>
        </span>
      </div>
    </nav>
  );
}

export default Header;
