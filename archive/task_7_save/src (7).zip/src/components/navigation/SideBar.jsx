// src/components/navigation/SideBar.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import './navigation.css';
import Activity from '../Activity';

// icônes depuis assets
import homeIcon from '../../assets/Frame1.png';
import favoritesIcon from '../../assets/Frame2.png';
import historyIcon from '../../assets/Frame3.png';

function SideBar() {
  const [selected, setSelected] = useState('home');          // default: "home"
  const [small] = useState(true);                            // default: true (demande du sujet)
  const [activities, setActivities] = useState([]);          // default: []
  const [showActivities, setShowActivities] = useState(false); // default: false

  const navigate = useNavigate();

  // Fonction demandée par le sujet
  const setPage = (pageName) => {
    setSelected(pageName.toLowerCase());

    if (pageName === 'Home') {
      navigate('/home');
    } else if (pageName === 'Favorites') {
      navigate('/favorites');
    } else if (pageName === 'Watch Later') {
      navigate('/watchlater');
    }
  };

  useEffect(() => {
    axios
      .get('/api/activity')
      .then((res) => {
        setActivities(res.data || []);
        setShowActivities(true);
      })
      .catch((err) => {
        console.error('Error fetching activities:', err);
      });
  }, []);

  return (
    <nav className={`sidebar ${small ? 'sidebar-small' : 'sidebar-large'}`}>
      {/* Navigation */}
      <ul className="sidebar-menu">
        <li
          className={`sidebar-item ${selected === 'home' ? 'active' : ''}`}
          onClick={() => setPage('Home')}
        >
          <img src={homeIcon} alt="Home" className="sidebar-icon" />
          <span className="sidebar-text">Home</span>
        </li>

        <li
          className={`sidebar-item ${selected === 'favorites' ? 'active' : ''}`}
          onClick={() => setPage('Favorites')}
        >
          <img src={favoritesIcon} alt="Favorites" className="sidebar-icon" />
          <span className="sidebar-text">Favorites</span>
        </li>

        <li
          className={`sidebar-item ${selected === 'watch later' ? 'active' : ''}`}
          onClick={() => setPage('Watch Later')}
        >
          <img src={historyIcon} alt="Watch Later" className="sidebar-icon" />
          <span className="sidebar-text">Watch Later</span>
        </li>
      </ul>

      {/* Latest Activities */}
      {showActivities && Array.isArray(activities) && (
        <ul className="sidebar-activities">
          {activities.slice(0, 10).map((act, idx) => (
            <Activity key={idx} activity={act} />
          ))}
        </ul>
      )}
    </nav>
  );
}

export default SideBar;
