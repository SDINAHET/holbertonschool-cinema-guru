// src/components/Activity.jsx
import './components.css';

function formatAction(action) {
  switch (action) {
    case 'watch_later':
      return 'added';
    case 'favorite':
      return 'added to favorites';
    default:
      return 'did something with';
  }
}

function Activity({ activity }) {
  if (!activity) return null;

  const {
    username,
    movieTitle,
    action,
    date,
  } = activity;

  const actionText =
    action === 'watch_later'
      ? 'added'
      : action === 'favorite'
      ? 'added'
      : 'did something with';

  const suffixText =
    action === 'watch_later'
      ? 'to watch later'
      : action === 'favorite'
      ? 'to favorites'
      : '';

  const formattedDate = date
    ? new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : '';

  return (
    <li className="activity-item">
      <p className="activity-text">
        <span className="activity-user">{username}</span>{' '}
        {actionText}{' '}
        <span className="activity-title">{movieTitle}</span>{' '}
        {suffixText}
        {formattedDate && (
          <>
            {' '}
            - <span className="activity-date">{formattedDate}</span>
          </>
        )}
      </p>
    </li>
  );
}

export default Activity;
