// src/components/navigation/SideBar.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import './navigation.css';
import Activity from '../Activity';

function SideBar() {
  const [selected, setSelected] = useState('home'); // "home" par défaut
  const [small, setSmall] = useState(true);         // sidebar étroite
  const [activities, setActivities] = useState([]); // []
  const [showActivities, setShowActivities] = useState(true);

  const navigate = useNavigate();

  const setPage = (pageName) => {
    setSelected(pageName);

    if (pageName === 'home') {
      navigate('/home');
    } else if (pageName === 'favorites') {
      navigate('/favorites');
    } else if (pageName === 'watchlater') {
      navigate('/watchlater');
    }
  };

  useEffect(() => {
    axios
      .get('/api/activity')
      .then((res) => {
        setActivities(res.data || []);
      })
      .catch((err) => {
        console.error('Error fetching activities:', err);
      });
  }, []);

  return (
    <nav className={`sidebar ${small ? 'sidebar-small' : 'sidebar-large'}`}>
      {/* Barre rouge avec icônes */}
      <ul className="sidebar-nav">
        <li
          className={selected === 'home' ? 'active' : ''}
          onClick={() => setPage('home')}
          title="Home"
        >
          <span className="sidebar-icon">📁</span>
        </li>

        <li
          className={selected === 'favorites' ? 'active' : ''}
          onClick={() => setPage('favorites')}
          title="Favorites"
        >
          <span className="sidebar-icon">⭐</span>
        </li>

        <li
          className={selected === 'watchlater' ? 'active' : ''}
          onClick={() => setPage('watchlater')}
          title="Watch Later"
        >
          <span className="sidebar-icon">⏱</span>
        </li>
      </ul>

      {/* Liste d'activités (affichée à côté / plus tard dans la maquette large) */}
      {showActivities && (
        <ul className="sidebar-activities">
          {activities.slice(0, 10).map((act, idx) => (
            <Activity key={idx} activity={act} />
          ))}
        </ul>
      )}
    </nav>
  );
}

export default SideBar;
