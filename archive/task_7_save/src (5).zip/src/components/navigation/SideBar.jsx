// src/components/navigation/SideBar.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import './navigation.css';
import Activity from '../Activity';

function SideBar() {
  const [selected, setSelected] = useState('home');      // default: "home"
  const [small] = useState(true);                       // default: true
  const [activities, setActivities] = useState([]);     // default: []
  const [showActivities, setShowActivities] = useState(false); // default: false

  const navigate = useNavigate();

  const setPage = (pageName) => {
    setSelected(pageName);

    if (pageName === 'home') {
      navigate('/home');
    } else if (pageName === 'favorites') {
      navigate('/favorites');
    } else if (pageName === 'watchlater') {
      navigate('/watchlater');
    }
  };

  useEffect(() => {
    axios
      .get('/api/activity')
      .then((res) => {
        setActivities(res.data || []);
        // on affiche les activités une fois les données chargées
        setShowActivities(true);
      })
      .catch((err) => {
        console.error('Error fetching activities:', err);
      });
  }, []);

  return (
    <nav className={`sidebar ${small ? 'sidebar-small' : 'sidebar-large'}`}>
      {/* Navigation ul */}
      <ul className="sidebar-nav">
        <li
          className={selected === 'home' ? 'active' : ''}
          onClick={() => setPage('home')}
          title="Home"
        >
          <span className="sidebar-icon">📁</span>
          <span className="sidebar-text">Home</span>
        </li>

        <li
          className={selected === 'favorites' ? 'active' : ''}
          onClick={() => setPage('favorites')}
          title="Favorites"
        >
          <span className="sidebar-icon">⭐</span>
          <span className="sidebar-text">Favorites</span>
        </li>

        <li
          className={selected === 'watchlater' ? 'active' : ''}
          onClick={() => setPage('watchlater')}
          title="Watch Later"
        >
          <span className="sidebar-icon">⏱</span>
          <span className="sidebar-text">Watch Later</span>
        </li>
      </ul>

      {/* Activity ul : map les 10 premières activités */}
      {showActivities && Array.isArray(activities) && (
        <ul className="sidebar-activities">
          {activities.slice(0, 10).map((act, idx) => (
            <Activity key={idx} activity={act} />
          ))}
        </ul>
      )}
    </nav>
  );
}

export default SideBar;
