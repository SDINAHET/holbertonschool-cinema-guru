// src/components/navigation/SideBar.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import './navigation.css';
import Activity from '../Activity';

// icônes depuis assets
import homeIcon from '../../assets/Frame1.png';
import favoritesIcon from '../../assets/Frame2.png';
import historyIcon from '../../assets/Frame3.png';

function SideBar() {
  const [selected, setSelected] = useState('home');
  const [activities, setActivities] = useState([]);
  const [showActivities, setShowActivities] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get('/api/activity')
      .then((res) => {
        setActivities(res.data || []);
        setShowActivities(true);
      })
      .catch((err) => {
        console.error('Error fetching activities:', err);
      });
  }, []);

  return (
    <nav className="sidebar">
      <ul className="sidebar-menu">
        <li
          className={`sidebar-item ${selected === 'home' ? 'active' : ''}`}
          onClick={() => {
            setSelected('home');
            navigate('/dashboard'); // ou '/home' si besoin
          }}
        >
          <img src={homeIcon} alt="Home" className="sidebar-icon" />
          <span className="sidebar-text">Home</span>
        </li>

        <li
          className={`sidebar-item ${selected === 'favorites' ? 'active' : ''}`}
          onClick={() => {
            setSelected('favorites');
            navigate('/favorites');
          }}
        >
          <img src={favoritesIcon} alt="Favorites" className="sidebar-icon" />
          <span className="sidebar-text">Favorites</span>
        </li>

        <li
          className={`sidebar-item ${selected === 'activity' ? 'active' : ''}`}
          onClick={() => {
            setSelected('activity');
            setShowActivities((prev) => !prev);
          }}
        >
          <img src={historyIcon} alt="Activity" className="sidebar-icon" />
          <span className="sidebar-text">Activity</span>
        </li>
      </ul>

      {showActivities && Array.isArray(activities) && (
        <ul className="sidebar-activities">
          {activities.slice(0, 10).map((act, idx) => (
            <Activity key={idx} activity={act} />
          ))}
        </ul>
      )}
    </nav>
  );
}

export default SideBar;
